"""Regenerate all figures + main table from TUNED results, plus a new
parameter-tuning sensitivity figure. Writes to ./figs_out and ./table_main.tex."""
import os, sys, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.join(HERE, "original_code")
sys.path.insert(0, CODE)
OUT = os.path.join(HERE, "results_tuned")
TUNE = os.path.join(HERE, "tune_out")
FIG = os.path.join(HERE, "figs_out")
os.makedirs(FIG, exist_ok=True)

plt.rcParams.update({
    "font.family": "serif", "font.size": 9, "axes.grid": True,
    "grid.alpha": 0.3, "grid.linewidth": 0.5, "axes.linewidth": 0.6,
    "legend.frameon": False, "figure.dpi": 150,
})
STY = {"RAND": ("#888888", "o", "Random+LS"),
       "PSO":  ("#1f77b4", "s", "PSO"),
       "GA":   ("#2ca02c", "^", "GA"),
       "HCHMA":("#d62728", "D", "HCH-MA")}


def fig_instance():
    from chp import make_instance, prefix, best_signs_for_bounds
    d, N = 4, 400
    M = make_instance(d, N, "adversarial", np.random.default_rng(5))
    x = np.linspace(0, 1, N)
    fig, axes = plt.subplots(2, 1, figsize=(5.2, 3.0), sharex=True,
                             gridspec_kw={"height_ratios": [3, 1]})
    cols = plt.cm.viridis(np.linspace(0.1, 0.85, d))
    for j in range(d):
        axes[0].plot(x, M[j] * N, color=cols[j], lw=1.3, label=f"$\\mu_{{{j+1}}}$")
    axes[0].set_ylabel("density")
    axes[0].legend(ncol=d, fontsize=7, loc="upper center", columnspacing=1.0)
    axes[0].set_title("Adversarial instance: $d$ disjoint valuations", fontsize=9)
    C = prefix(M)
    med = np.sort([int(np.searchsorted(C[j], 0.5 * C[j, N])) for j in range(d)])
    bounds = np.concatenate(([0], med, [N]))
    signs, F = best_signs_for_bounds(C, bounds)
    for i in range(len(bounds) - 1):
        color = "#d62728" if signs[i] > 0 else "#1f77b4"
        axes[1].axvspan(bounds[i] / N, bounds[i + 1] / N, color=color, alpha=0.55)
    for b in bounds[1:-1]:
        axes[0].axvline(b / N, color="k", ls="--", lw=0.7, alpha=0.7)
    axes[1].set_yticks([]); axes[1].set_xlabel("position on the cake $[0,1]$")
    axes[1].set_ylabel("split", fontsize=8)
    axes[1].text(0.01, 0.5, f"$F={F:.3f}$", transform=axes[1].transAxes,
                 fontsize=8, va="center")
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "instance.pdf"),
                                    bbox_inches="tight"); plt.close(fig)


def fig_convergence():
    d = np.load(os.path.join(OUT, "exp3_convergence.npz"))
    grids = d["grids"]
    fig, ax = plt.subplots(figsize=(4.0, 3.0))
    for m in ["RAND", "PSO", "GA", "HCHMA"]:
        c, mk, lab = STY[m]
        ax.plot(grids, d[m], color=c, lw=1.6, label=lab)
    ax.set_yscale("log"); ax.set_xlabel("wall-clock time (s)")
    ax.set_ylabel("best imbalance $F$ (log)")
    ax.set_title("Convergence, adversarial $d=8$", fontsize=9)
    ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "convergence.pdf"),
                                    bbox_inches="tight"); plt.close(fig)


def fig_scalability():
    rows = json.load(open(os.path.join(OUT, "exp2_scalability.json")))
    kinds = sorted(set(r["kind"] for r in rows))
    fig, axes = plt.subplots(1, len(kinds), figsize=(6.6, 2.7), sharey=True)
    if len(kinds) == 1:
        axes = [axes]
    for ax, kind in zip(axes, kinds):
        rk = [r for r in rows if r["kind"] == kind]
        ds = [r["d"] for r in rk]
        for m in ["PSO", "GA", "HCHMA"]:
            c, mk, lab = STY[m]
            mean = [max(r[f"{m}_mean"], 1e-6) for r in rk]
            ax.plot(ds, mean, color=c, marker=mk, ms=4, lw=1.4, label=lab)
        ax.set_yscale("log"); ax.set_xlabel("dimension $d$")
        ax.set_title(kind, fontsize=9)
    axes[0].set_ylabel("final imbalance $F$ (log)")
    axes[-1].legend(fontsize=8)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "scalability.pdf"),
                                    bbox_inches="tight"); plt.close(fig)


def fig_ablation():
    rows = json.load(open(os.path.join(OUT, "exp4_ablation.json")))
    ds = sorted(set(r["d"] for r in rows))
    variants = ["Full (adaptive)", "Periodic VND", "No seed", "No VND",
                "Neither (PSO)"]
    cols = ["#d62728", "#e377c2", "#ff7f0e", "#9467bd", "#1f77b4"]
    fig, ax = plt.subplots(figsize=(4.8, 3.0))
    w = 0.16; xpos = np.arange(len(ds))
    for i, v in enumerate(variants):
        means, errs = [], []
        for dd in ds:
            rec = [r for r in rows if r["d"] == dd and r["variant"] == v]
            means.append(max(rec[0]["mean"], 1e-6) if rec else np.nan)
            errs.append(rec[0]["std"] if rec else 0.0)
        ax.bar(xpos + (i - 2) * w, means, w, yerr=errs, capsize=2,
               color=cols[i], label=v, edgecolor="k", linewidth=0.4)
    ax.set_yscale("log")
    ax.set_xticks(xpos); ax.set_xticklabels([f"$d={dd}$" for dd in ds])
    ax.set_ylabel("final imbalance $F$ (log)")
    ax.set_title("Ablation on adversarial instances", fontsize=9)
    ax.legend(fontsize=6.5, ncol=1)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "ablation.pdf"),
                                    bbox_inches="tight"); plt.close(fig)


def fig_tuning():
    """Sensitivity around the deployed (rank-selected) configuration. For each
    parameter we vary it with the others fixed at the deployed value and score
    the slice by mean Friedman rank across the calibration instances (the same
    scale-robust criterion used for selection). Lower rank is better; the open
    red marker is the selected value."""
    import json as _j
    DEPLOY = {"w": 0.4, "c1": 2.0, "c2": 2.0, "swarm": 80,
              "stag_window": 5, "ls_elites": 1, "ls_sweeps": 10}

    def key(c):
        return _j.dumps({k: c[k] for k in ["w", "c1", "c2", "swarm",
                        "stag_window", "ls_elites", "ls_sweeps"]}, sort_keys=True)

    core = _j.load(open(os.path.join(TUNE, "sens_core.json")))   # key -> F list
    s2 = _j.load(open(os.path.join(TUNE, "stage2_memetic.json")))
    s2map = {key(r["cfg"]): r["F"] for r in s2}

    def Fvec(c):
        k = key(c)
        if k in core:
            return core[k]
        if k in s2map:
            return s2map[k]
        return None

    def slice_rank(param, grid):
        vals, Fmat = [], []
        for v in grid:
            c = dict(DEPLOY)
            if param == "c1":
                c["c1"] = c["c2"] = v
            else:
                c[param] = v
            fv = Fvec(c)
            if fv is not None:
                vals.append(v); Fmat.append(fv)
        Fmat = np.array(Fmat)                      # (nval, ninst)
        ranks = np.apply_along_axis(
            lambda col: np.argsort(np.argsort(col)) + 1, 0, Fmat).astype(float)
        return vals, ranks.mean(axis=1)

    panels = [
        ("inertia $w$", slice_rank("w", [0.4, 0.6, 0.72, 0.9]), 0.4),
        ("accel. $c_1{=}c_2$", slice_rank("c1", [1.0, 1.49, 2.0]), 2.0),
        ("swarm size $m$", slice_rank("swarm", [20, 40, 80]), 80),
        ("stagnation $\\omega$", slice_rank("stag_window", [5, 15, 30, 60]), 5),
        ("elites $\\eta$", slice_rank("ls_elites", [1, 3, 5]), 1),
        ("VND sweeps", slice_rank("ls_sweeps", [10, 20, 40]), 10),
    ]
    fig, axes = plt.subplots(2, 3, figsize=(6.6, 3.8))
    for ax, (lab, (xs, ys), opt) in zip(axes.ravel(), panels):
        ax.plot(xs, ys, "-o", color="#1f77b4", ms=4, lw=1.3)
        if opt in xs:
            ax.plot([opt], [ys[xs.index(opt)]], "o", color="#d62728", ms=9,
                    mfc="none", mew=1.8)
        ax.set_xlabel(lab)
        ax.set_ylim(0.5, max(len(xs) for _, (xs, _), _ in panels) + 0.5)
    axes[0, 0].set_ylabel("mean rank (lower better)")
    axes[1, 0].set_ylabel("mean rank (lower better)")
    fig.suptitle("Parameter sensitivity on the calibration set "
                 "(red = selected value)", fontsize=9)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(os.path.join(FIG, "tuning.pdf"), bbox_inches="tight")
    plt.close(fig)


def table_main():
    rows = json.load(open(os.path.join(OUT, "exp1_main.json")))
    methods = ["RAND", "PSO", "GA", "HCHMA"]
    nice = {"RAND": "Random+LS", "PSO": "PSO", "GA": "GA",
            "HCHMA": "\\textbf{HCH-MA}"}
    out = []
    out.append("\\begin{table*}[t]")
    out.append("\\centering")
    out.append("\\caption{Mean worst-case imbalance $F$ (lower is better) under an "
               "equal, size-scaled time budget $T(d)=\\max(0.8,0.20d)$\\,s, over "
               "eight independent instances per cell ($N=5000$ grid points), using "
               "the tuned configuration of Section~\\ref{sec:tuning}. Best per row "
               "in bold. The last column is the HCH-MA success rate (fraction of "
               "runs with $F<0.05$). Generic metaheuristics collapse to the "
               "worst-case $F\\!\\approx\\!1$ on adversarial instances for $d\\ge12$, "
               "whereas HCH-MA remains near-optimal.}")
    out.append("\\label{tab:main}")
    out.append("\\begin{tabular*}{\\tblwidth}{@{\\extracolsep{\\fill}}ll"
               + "r" * len(methods) + "r@{}}")
    out.append("\\toprule")
    out.append("Family & $d$ & " + " & ".join(nice[m] for m in methods)
               + " & HCH-MA succ. \\\\")
    out.append("\\midrule")
    last_kind = None
    for r in rows:
        best = min(r[f"{m}_mean"] for m in methods)
        cells = []
        for m in methods:
            val = r[f"{m}_mean"]; s = f"{val:.4f}"
            if abs(val - best) < 1e-9:
                s = "\\textbf{" + s + "}"
            cells.append(s)
        fam = r["kind"] if r["kind"] != last_kind else ""
        if r["kind"] != last_kind and last_kind is not None:
            out.append("\\midrule")
        last_kind = r["kind"]
        succ = f"{r['HCHMA_succ']*100:.0f}\\%"
        out.append(f"{fam} & {r['d']} & " + " & ".join(cells) + f" & {succ} \\\\")
    out.append("\\bottomrule")
    out.append("\\end{tabular*}")
    out.append("\\end{table*}")
    open(os.path.join(HERE, "table_main.tex"), "w").write("\n".join(out))


if __name__ == "__main__":
    table_main(); fig_convergence(); fig_scalability(); fig_ablation()
    fig_instance(); fig_tuning()
    print("figures + table written to", FIG)

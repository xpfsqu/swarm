"""Tune the DE and GWO baselines on the same calibration set (rank criterion),
so every competitor is tuned on equal footing."""
import os, sys, json, itertools
import numpy as np
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from tune import CAL, budget, OUT, NGRID, FAMILIES, rank_select, NPROC
CODE = os.path.join(HERE, "original_code")
sys.path.insert(0, CODE)
from chp import make_instance
from solvers import de, gwo

def eval_method(fn, kw):
    fs = []
    for (fam, d, iseed) in CAL:
        M = make_instance(d, NGRID, fam, np.random.default_rng(iseed))
        rng = np.random.default_rng(50000 + iseed)
        f, _ = fn(M, NGRID, rng, time_budget=budget(d), **kw)
        fs.append(float(f))
    return fs

def _de(args):
    i, kw = args; return ("de", i, eval_method(de, kw))
def _gwo(args):
    i, kw = args; return ("gwo", i, eval_method(gwo, kw))

if __name__ == "__main__":
    de_cfgs = [{"pop": p, "F": f, "CR": c}
               for p, f, c in itertools.product([30, 50, 80], [0.4, 0.6, 0.8], [0.5, 0.9])]
    gwo_cfgs = [{"pop": p} for p in [20, 40, 80]]
    de_rec = [None] * len(de_cfgs); gwo_rec = [None] * len(gwo_cfgs)
    with Pool(NPROC) as pool:
        for tag, i, fs in pool.imap_unordered(_de, list(enumerate(de_cfgs))):
            r = {"cfg": de_cfgs[i], "F": fs, "mean_overall": float(np.mean(fs))}
            for fam in FAMILIES:
                r[f"mean_{fam}"] = float(np.mean([fs[k] for k,(f,d,s) in enumerate(CAL) if f==fam]))
            de_rec[i] = r
            print("DE", de_cfgs[i], "overall", round(np.mean(fs),4), flush=True)
    with Pool(NPROC) as pool:
        for tag, i, fs in pool.imap_unordered(_gwo, list(enumerate(gwo_cfgs))):
            r = {"cfg": gwo_cfgs[i], "F": fs, "mean_overall": float(np.mean(fs))}
            for fam in FAMILIES:
                r[f"mean_{fam}"] = float(np.mean([fs[k] for k,(f,d,s) in enumerate(CAL) if f==fam]))
            gwo_rec[i] = r
            print("GWO", gwo_cfgs[i], "overall", round(np.mean(fs),4), flush=True)
    bd, de_rec = rank_select(de_rec); bg, gwo_rec = rank_select(gwo_rec)
    out = {"de_best": de_rec[bd]["cfg"], "gwo_best": gwo_rec[bg]["cfg"],
           "de_records": de_rec, "gwo_records": gwo_rec}
    json.dump(out, open(os.path.join(OUT, "de_gwo_config.json"), "w"), indent=2)
    print("DE BEST:", de_rec[bd]["cfg"], "| GWO BEST:", gwo_rec[bg]["cfg"], flush=True)
    open(os.path.join(OUT, "DEGWO_DONE.flag"), "w").write("done")

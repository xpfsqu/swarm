"""Light tuning of the GA baseline (pop, pc, pm) on the same calibration set,
so the comparison cannot be criticised as tuning only HCH-MA. Rank-aggregated."""
import os, sys, json, itertools, time
import numpy as np
from multiprocessing import Pool
CODE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "original_code")
sys.path.insert(0, CODE)
from chp import make_instance
from solvers import ga
from tune import CAL, budget, OUT, NGRID, FAMILIES, rank_select, NPROC

def _worker(args):
    idx, kw = args
    fs = []
    for (fam, d, inst_seed) in CAL:
        M = make_instance(d, NGRID, fam, np.random.default_rng(inst_seed))
        rng = np.random.default_rng(50000 + inst_seed)
        f, _ = ga(M, NGRID, rng, time_budget=budget(d), **kw)
        fs.append(float(f))
    return idx, fs

if __name__ == "__main__":
    pops = [40, 60, 100]; pcs = [0.7, 0.9]; pms = [0.1, 0.2, 0.3]
    configs = [{"pop": p, "pc": c, "pm": m}
               for p, c, m in itertools.product(pops, pcs, pms)]
    recs = [None] * len(configs)
    with Pool(NPROC) as pool:
        for idx, fs in pool.imap_unordered(
                _worker, list(enumerate(configs))):
            r = {"cfg": configs[idx], "F": fs, "mean_overall": float(np.mean(fs))}
            for fam in FAMILIES:
                r[f"mean_{fam}"] = float(np.mean(
                    [fs[k] for k, (f, d, s) in enumerate(CAL) if f == fam]))
            recs[idx] = r
            print("GA", configs[idx], "overall", round(np.mean(fs), 4), flush=True)
    b, recs = rank_select(recs)
    best = recs[b]["cfg"]
    json.dump({"ga_best": best, "records": recs},
              open(os.path.join(OUT, "ga_config.json"), "w"), indent=2)
    print("GA BEST:", best, flush=True)

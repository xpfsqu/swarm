"""Dedicated one-factor-at-a-time (OFAT) sweep around the mean-F optimum, so the
final configuration is coordinate-wise optimal and the sensitivity figure is
self-consistent. Selection criterion: mean F over the calibration set."""
import os, sys, json, itertools
import numpy as np
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from tune import CAL, budget, OUT, NGRID, FAMILIES, NPROC
CODE = os.path.join(HERE, "original_code")
sys.path.insert(0, CODE)
from chp import make_instance
from solvers import hchma

CENTER = {"w": 0.6, "c1": 2.0, "c2": 2.0, "swarm": 80,
          "stag_window": 15, "ls_elites": 3, "ls_sweeps": 20}
GRID = {"w": [0.4, 0.6, 0.72, 0.9],
        "c1": [1.0, 1.49, 2.0],
        "swarm": [20, 40, 80],
        "stag_window": [5, 15, 30, 60],
        "ls_elites": [1, 3, 5],
        "ls_sweeps": [10, 20, 40]}

def cfg_key(c):
    return json.dumps({k: c[k] for k in ["w", "c1", "c2", "swarm",
                       "stag_window", "ls_elites", "ls_sweeps"]}, sort_keys=True)

def eval_cfg(c):
    fs = []
    for (fam, d, iseed) in CAL:
        M = make_instance(d, NGRID, fam, np.random.default_rng(iseed))
        rng = np.random.default_rng(50000 + iseed)
        f, _ = hchma(M, NGRID, rng, time_budget=budget(d),
                     seed_greedy=True, use_ls=True, adaptive=True, **c)
        fs.append(float(f))
    return fs

def _worker(ck):
    c = json.loads(ck); c["c2"] = c["c1"]
    return ck, eval_cfg(c)

if __name__ == "__main__":
    # build all configs needed by the six OFAT slices (c1=c2 enforced)
    needed = {}
    for param, vals in GRID.items():
        for v in vals:
            c = dict(CENTER)
            if param == "c1":
                c["c1"] = c["c2"] = v
            else:
                c[param] = v
            needed[cfg_key(c)] = c
    print(f"{len(needed)} unique configs", flush=True)
    results = {}
    with Pool(NPROC) as pool:
        for ck, fs in pool.imap_unordered(_worker, list(needed.keys())):
            results[ck] = {"mean": float(np.mean(fs)), "F": fs}
            print("done", json.loads(ck)["w"], json.loads(ck)["c1"],
                  json.loads(ck)["swarm"], json.loads(ck)["stag_window"],
                  json.loads(ck)["ls_elites"], json.loads(ck)["ls_sweeps"],
                  "->", round(np.mean(fs), 5), flush=True)
            json.dump(results, open(os.path.join(OUT, "ofat.json"), "w"), indent=2)
    # per-slice argmin -> final coordinate-optimal config
    final = dict(CENTER)
    slices = {}
    for param, vals in GRID.items():
        pts = []
        for v in vals:
            c = dict(CENTER)
            if param == "c1":
                c["c1"] = c["c2"] = v
            else:
                c[param] = v
            pts.append((v, results[cfg_key(c)]["mean"]))
        slices[param] = pts
        best_v = min(pts, key=lambda t: t[1])[0]
        final[param] = best_v
        if param == "c1":
            final["c2"] = best_v
    json.dump({"final": final, "center": CENTER, "slices": slices},
              open(os.path.join(OUT, "ofat_final.json"), "w"), indent=2)
    print("FINAL (mean-F, coordinate-optimal):", final, flush=True)
    coord_opt = all(final[p] == CENTER[p] for p in GRID if p != "c1") and \
        final["c1"] == CENTER["c1"]
    print("center is coordinate-optimal:", coord_opt, flush=True)
    open(os.path.join(OUT, "OFAT_DONE.flag"), "w").write("done")

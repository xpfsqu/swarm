"""
Consensus-Halving as a fair resource-allocation optimization problem.

Model (two-player exact-fairness / n=d agents form):
  Cake = interval [0,1].  There are d measures (valuations) mu_1..mu_d, each a
  probability distribution on [0,1] (sum = 1).  We place d cut points, producing
  d+1 pieces, and assign a sign s_i in {+1,-1} to each piece (which of the two
  players receives it).  For every measure j the "+"-mass must equal the
  "-"-mass, i.e. the signed mass sum_i s_i * mu_j(piece_i) = 0.

  The infinity-imbalance (the epsilon of epsilon-consensus-halving) is
        F(x) = max_j | sum_i s_i * mu_j(piece_i) |.
  A perfectly fair split has F = 0; we search for min F.

Discretization: measures live on a common grid of N bins; a cut configuration
is d integer boundaries 0<=b_1<=...<=b_d<=N (multiples of 1/N).  Everything is
vectorized through prefix sums, so a fitness evaluation is O(d_measures * d).
"""
import numpy as np


# --------------------------------------------------------------------------
# Benchmark instance generation
# --------------------------------------------------------------------------
def make_instance(d, N, kind, rng):
    """Return measure matrix M of shape (d, N): row j = discretized mu_j, sums to 1."""
    M = np.zeros((d, N))
    x = (np.arange(N) + 0.5) / N
    if kind == "uniform":
        # piecewise-constant densities with random block heights
        n_blocks = max(4, N // 50)
        edges = np.linspace(0, N, n_blocks + 1).astype(int)
        for j in range(d):
            for k in range(n_blocks):
                M[j, edges[k]:edges[k + 1]] = rng.uniform(0.2, 1.0)
    elif kind == "normal":
        # each measure a mixture of 1-3 Gaussians at random centres
        for j in range(d):
            n_comp = rng.integers(1, 4)
            for _ in range(n_comp):
                c = rng.uniform(0.1, 0.9)
                w = rng.uniform(0.03, 0.15)
                M[j] += rng.uniform(0.5, 1.0) * np.exp(-0.5 * ((x - c) / w) ** 2)
    elif kind == "adversarial":
        # the extreme case of Fig 2-1: each measure concentrated on its own
        # disjoint sub-interval, so d cuts are genuinely necessary.
        seg = N // d
        for j in range(d):
            lo, hi = j * seg, (j + 1) * seg if j < d - 1 else N
            # sharp bump inside the private segment
            c = (lo + hi) / 2.0
            w = max(1.0, 0.15 * (hi - lo))
            idx = np.arange(lo, hi)
            M[j, lo:hi] = np.exp(-0.5 * ((idx - c) / w) ** 2) + 0.05
    else:
        raise ValueError(kind)
    M = np.maximum(M, 1e-12)
    M /= M.sum(axis=1, keepdims=True)
    return M


# --------------------------------------------------------------------------
# Fitness (infinity-imbalance) evaluation utilities
# --------------------------------------------------------------------------
def prefix(M):
    """Prefix sums, shape (d, N+1); C[j,b] = mass of mu_j on bins [0,b)."""
    d, N = M.shape
    C = np.zeros((d, N + 1))
    C[:, 1:] = np.cumsum(M, axis=1)
    return C


def fitness_from_bounds(C, bounds, signs):
    """
    C: (d, N+1) prefix sums.
    bounds: integer array length d+2, 0 = b0 <= b1 <= ... <= b_{d+1} = N.
    signs: array length d+1 in {+1,-1}.
    Returns F = max_j |signed mass|.
    """
    piece_mass = C[:, bounds[1:]] - C[:, bounds[:-1]]     # (d, d+1)
    signed = piece_mass @ signs                            # (d,)
    return np.max(np.abs(signed)), signed


def best_signs_for_bounds(C, bounds, restarts=True):
    """
    Given fixed cut boundaries, choose piece signs minimizing the max-norm
    imbalance  max_j |sum_i s_i * mass_{ji}|.  This min-max sign-assignment is
    the combinatorial core of consensus halving; we solve it heuristically with
    (i) a greedy L2 seed, (ii) an alternating seed, and (iii) a 1-flip descent.
    Returns (signs, F).
    """
    piece_mass = C[:, bounds[1:]] - C[:, bounds[:-1]]      # (d, npiece)
    npiece = piece_mass.shape[1]

    def polish(signs):
        running = piece_mass @ signs
        F = np.max(np.abs(running))
        improved = True
        while improved:
            improved = False
            for i in range(npiece):
                trial = running - 2 * signs[i] * piece_mass[:, i]
                Ft = np.max(np.abs(trial))
                if Ft < F - 1e-15:
                    signs[i] = -signs[i]; running = trial; F = Ft; improved = True
        return signs, F

    # seed 1: greedy L2 balancing in decreasing-norm order
    s1 = np.ones(npiece)
    running = piece_mass[:, 0] * 0.0
    for i in np.argsort(-np.linalg.norm(piece_mass, axis=0)):
        col = piece_mass[:, i]
        if np.sum((running + col) ** 2) <= np.sum((running - col) ** 2):
            s1[i] = 1.0; running = running + col
        else:
            s1[i] = -1.0; running = running - col
    cand = [polish(s1.copy())]
    if restarts:
        # seed 2: strict alternation (optimal structure for disjoint measures)
        s2 = np.array([1.0 if i % 2 == 0 else -1.0 for i in range(npiece)])
        cand.append(polish(s2.copy()))
        # seed 3: greedy without reordering
        s3 = np.ones(npiece); run = piece_mass[:, 0] * 0.0
        for i in range(npiece):
            col = piece_mass[:, i]
            if np.sum((run + col) ** 2) <= np.sum((run - col) ** 2):
                s3[i] = 1.0; run = run + col
            else:
                s3[i] = -1.0; run = run - col
        cand.append(polish(s3.copy()))
    best = min(cand, key=lambda x: x[1])
    return best[0], best[1]


# --------------------------------------------------------------------------
# Encoding helpers (cross-polytope <-> grid boundaries)
# --------------------------------------------------------------------------
def polytope_to_bounds(p, N):
    """
    p: real vector length d+1 with sum|p| ~ 1.  |p_i| = length of piece i,
    sign(p_i) = assignment.  Returns integer boundaries (len d+2) and signs.
    """
    lengths = np.abs(p)
    s = lengths.sum()
    if s <= 0:
        lengths = np.ones_like(lengths)
        s = lengths.sum()
    lengths = lengths / s
    cum = np.concatenate(([0.0], np.cumsum(lengths)))
    bounds = np.clip(np.round(cum * N).astype(int), 0, N)
    bounds[0], bounds[-1] = 0, N
    bounds = np.maximum.accumulate(bounds)
    signs = np.sign(p)
    signs[signs == 0] = 1.0
    return bounds, signs

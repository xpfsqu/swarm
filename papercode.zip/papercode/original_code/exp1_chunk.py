import sys, json, os, numpy as np, time
from chp import make_instance
from run_experiments import run_method, budget, OUT, METHODS, EPS_TARGET
kind=sys.argv[1]; seeds=int(sys.argv[2]); tlimit=float(sys.argv[3])
ds=(2,4,8,16,24)
fn=os.path.join(OUT,f"exp1_{kind}.json")
rows=json.load(open(fn)) if os.path.exists(fn) else []
done={r["d"] for r in rows}; t0=time.time()
for d in ds:
    if d in done: continue
    if time.time()-t0>tlimit: break
    T=budget(d); per={m:[] for m in METHODS}; per_t={m:[] for m in METHODS}
    raw={m:[] for m in METHODS}
    for s in range(seeds):
        M=make_instance(d,5000,kind,np.random.default_rng(7*s+3))
        for m in METHODS:
            f,t=run_method(m,M,5000,s,T); per[m].append(f); per_t[m].append(t)
    row={"kind":kind,"d":d,"N":5000,"T":T}
    for m in METHODS:
        a=np.array(per[m]); row[f"{m}_mean"]=float(a.mean()); row[f"{m}_std"]=float(a.std())
        row[f"{m}_time"]=float(np.mean(per_t[m])); row[f"{m}_succ"]=float(np.mean(a<EPS_TARGET))
        row[f"{m}_raw"]=[float(x) for x in a]
    rows.append(row); json.dump(rows,open(fn,"w"),indent=2)
    print(kind,"d=",d,{m:round(row[f'{m}_mean'],4) for m in METHODS},"| HCHMA_t=",round(row['HCHMA_time'],2),flush=True)
print("done d=",sorted({r['d'] for r in rows}))

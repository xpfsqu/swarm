import sys, json, os, time
import numpy as np
from chp import make_instance
from run_experiments import run_method, budget, OUT
kind = sys.argv[1]; seeds = int(sys.argv[2]); tlimit=float(sys.argv[3])
ds=(2,4,8,16,24,32); ms=["PSO","GA","HCHMA"]
fn=os.path.join(OUT,f"exp2_{kind}.json")
rows=json.load(open(fn)) if os.path.exists(fn) else []
done={r["d"] for r in rows}
t0=time.time()
for d in ds:
    if d in done: continue
    if time.time()-t0>tlimit: break
    T=budget(d); per={m:[] for m in ms}; per_t={m:[] for m in ms}
    for s in range(seeds):
        M=make_instance(d,5000,kind,np.random.default_rng(11*s+5))
        for m in ms:
            f,t=run_method(m,M,5000,s,T); per[m].append(f); per_t[m].append(t)
    row={"kind":kind,"d":d,"T":T}
    for m in ms:
        row[f"{m}_mean"]=float(np.mean(per[m])); row[f"{m}_std"]=float(np.std(per[m])); row[f"{m}_time"]=float(np.mean(per_t[m]))
    rows.append(row); json.dump(rows,open(fn,"w"),indent=2)
    print(kind,"d=",d,{m:round(row[f'{m}_mean'],4) for m in ms},flush=True)
print("chunk end; done d=",sorted({r['d'] for r in rows}))

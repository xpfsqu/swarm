"""Large-scale experimental suite -> ./out (size-scaled budgets, Wilcoxon tests)."""
import os, json, time
import numpy as np
from scipy.stats import wilcoxon
from chp import make_instance
from solvers import (brute_force, random_multistart, pso, ga, hchma)

OUT = os.path.join(os.path.dirname(__file__), "out")
os.makedirs(OUT, exist_ok=True)
GLOBAL_T0 = time.time()
EPS_TARGET = 0.05
NGRID = 5000

def log(*a):
    print(f"[{time.time()-GLOBAL_T0:6.1f}s]", *a, flush=True)

def budget(d):
    return max(0.8, 0.20 * d)

def run_method(name, M, N, seed, T):
    rng = np.random.default_rng(1000 + seed)
    if name == "RAND":
        return random_multistart(M, N, rng, polish=True, time_budget=T)
    if name == "PSO":
        return pso(M, N, rng, swarm=40, time_budget=T)
    if name == "GA":
        return ga(M, N, rng, pop=60, time_budget=T)
    if name == "HCHMA":
        return hchma(M, N, rng, swarm=40, adaptive=True, stag_window=30,
                     ls_elites=3, ls_sweeps=20, time_budget=T)

METHODS = ["RAND", "PSO", "GA", "HCHMA"]
KINDS = ["uniform", "normal", "adversarial"]

def exp1(N=NGRID, ds=(2, 4, 8, 16, 24), seeds=range(8)):
    rows = []
    paired = {k: {"HCHMA": [], "PSO": []} for k in KINDS}   # for Wilcoxon
    for kind in KINDS:
        for d in ds:
            T = budget(d)
            per = {m: [] for m in METHODS}; per_t = {m: [] for m in METHODS}
            bf_vals = []
            for s in seeds:
                M = make_instance(d, N, kind, np.random.default_rng(7*s+3))
                for m in METHODS:
                    f, t = run_method(m, M, N, s, T)
                    per[m].append(f); per_t[m].append(t)
                paired[kind]["HCHMA"].append(per["HCHMA"][-1])
                paired[kind]["PSO"].append(per["PSO"][-1])
                if d == 2:
                    Ms = make_instance(2, 150, kind, np.random.default_rng(7*s+3))
                    bf, _, _ = brute_force(Ms, 150, time_budget=6)
                    bf_vals.append(bf)
            row = {"kind": kind, "d": d, "N": N, "T": T}
            for m in METHODS:
                a = np.array(per[m])
                row[f"{m}_mean"] = float(a.mean()); row[f"{m}_std"] = float(a.std())
                row[f"{m}_time"] = float(np.mean(per_t[m]))
                row[f"{m}_succ"] = float(np.mean(a < EPS_TARGET))
                row[f"{m}_raw"] = [float(x) for x in a]
            if bf_vals:
                row["BF_mean"] = float(np.mean(bf_vals))
            rows.append(row)
            log("exp1", kind, "d=", d, {m: round(row[f'{m}_mean'],4) for m in METHODS})
    # Wilcoxon signed-rank HCHMA vs PSO, per family (paired over all d,seed)
    sig = {}
    for kind in KINDS:
        h = np.array(paired[kind]["HCHMA"]); p = np.array(paired[kind]["PSO"])
        diff = h - p
        if np.any(diff != 0):
            stat, pv = wilcoxon(h, p)
        else:
            stat, pv = 0.0, 1.0
        sig[kind] = {"p_value": float(pv), "median_HCHMA": float(np.median(h)),
                     "median_PSO": float(np.median(p)),
                     "n_pairs": int(len(h)),
                     "HCHMA_better_frac": float(np.mean(h < p)),
                     "tie_frac": float(np.mean(h == p))}
        log("exp1 Wilcoxon", kind, "p=", round(pv, 3+ (pv==0)*0), sig[kind])
    json.dump(rows, open(os.path.join(OUT, "exp1_main.json"), "w"), indent=2)
    json.dump(sig, open(os.path.join(OUT, "exp1_significance.json"), "w"), indent=2)

def exp2(N=NGRID, ds=(2,4,8,16,24,32), kinds=("normal","adversarial"), seeds=range(5)):
    ms = ["PSO", "GA", "HCHMA"]; rows = []
    for kind in kinds:
        for d in ds:
            T = budget(d)
            per = {m: [] for m in ms}; per_t = {m: [] for m in ms}
            for s in seeds:
                M = make_instance(d, N, kind, np.random.default_rng(11*s+5))
                for m in ms:
                    f, t = run_method(m, M, N, s, T)
                    per[m].append(f); per_t[m].append(t)
            row = {"kind": kind, "d": d, "T": T}
            for m in ms:
                row[f"{m}_mean"] = float(np.mean(per[m]))
                row[f"{m}_std"] = float(np.std(per[m]))
                row[f"{m}_time"] = float(np.mean(per_t[m]))
            rows.append(row)
            log("exp2", kind, "d=", d, {m: round(row[f'{m}_mean'],4) for m in ms})
    json.dump(rows, open(os.path.join(OUT, "exp2_scalability.json"), "w"), indent=2)

def exp3(N=NGRID, d=16, kind="adversarial", seeds=range(6), T=6.0):
    grids = np.linspace(0.05, T, 160); agg = {}
    for m in METHODS:
        allc = []
        for s in seeds:
            M = make_instance(d, N, kind, np.random.default_rng(13*s+2))
            rng = np.random.default_rng(1000+s)
            if m == "RAND":
                _,_,curve = random_multistart(M,N,rng,polish=True,time_budget=T,record=True)
            elif m == "PSO":
                _,_,curve = pso(M,N,rng,swarm=40,time_budget=T,record=True)
            elif m == "GA":
                _,_,curve = ga(M,N,rng,pop=60,time_budget=T,record=True)
            else:
                _,_,curve = hchma(M,N,rng,swarm=40,adaptive=True,stag_window=30,time_budget=T,record=True)
            ct = np.array([c[0] for c in curve]); cf = np.array([c[1] for c in curve])
            vals = np.array([cf[ct<=g][-1] if np.any(ct<=g) else cf[0] for g in grids])
            allc.append(vals)
        agg[m] = np.mean(allc, axis=0)
        log("exp3", m, "final", round(agg[m][-1],5))
    np.savez(os.path.join(OUT, "exp3_convergence.npz"), grids=grids, **agg)

def exp4(N=NGRID, kind="adversarial", seeds=range(6), T=4.0):
    variants = {
        "Full (adaptive)": dict(seed_greedy=True,  use_ls=True, adaptive=True,  stag_window=30),
        "Periodic VND":    dict(seed_greedy=True,  use_ls=True, adaptive=False, ls_period=15),
        "No seed":         dict(seed_greedy=False, use_ls=True, adaptive=True,  stag_window=30),
        "No VND":          dict(seed_greedy=True,  use_ls=False),
        "Neither (PSO)":   dict(seed_greedy=False, use_ls=False),
    }
    rows = []
    for d in (8, 16):
        for name, kw in variants.items():
            vals = []
            for s in seeds:
                M = make_instance(d, N, kind, np.random.default_rng(17*s+1))
                rng = np.random.default_rng(1000+s)
                f, _ = hchma(M, N, rng, swarm=40, time_budget=T, **kw)
                vals.append(f)
            rows.append({"d": d, "variant": name, "mean": float(np.mean(vals)), "std": float(np.std(vals))})
            log("exp4 d=", d, name, round(np.mean(vals),5))
    json.dump(rows, open(os.path.join(OUT, "exp4_ablation.json"), "w"), indent=2)

if __name__ == "__main__":
    log("START"); exp1(); exp2(); exp3(); exp4(); log("DONE")
    open(os.path.join(os.path.dirname(__file__), "DONE.flag"), "w").write("done")

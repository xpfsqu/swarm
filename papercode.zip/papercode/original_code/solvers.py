"""Solvers / baselines for discrete consensus halving."""
import time
import numpy as np
from itertools import combinations, product
from chp import (prefix, fitness_from_bounds, best_signs_for_bounds,
                 polytope_to_bounds)


# --------------------------------------------------------------------------
# Variable Neighborhood Descent (VND) local search -- the memetic refinement.
#   N1 (shift):      steepest descent moving each interior cut by +/- steps.
#   N2 (relocation): a large "repair" move that relocates the least useful cut
#                    to the median of the currently most-imbalanced measure,
#                    which lets the search place a cut in an empty region -- the
#                    move that is essential on adversarial (disjoint) instances.
# An embedded optimal-sign repair is applied after every structural change.
# --------------------------------------------------------------------------
def _median_of_measure(C, j, N):
    """Grid index where measure j reaches half of its total mass."""
    target = 0.5 * C[j, N]
    return int(np.searchsorted(C[j], target))


def _neighborhood_shift(C, bounds, signs, F, step_set, deadline):
    changed = False
    for i in range(1, len(bounds) - 1):
        if time.time() > deadline:
            break
        lo, hi = bounds[i - 1], bounds[i + 1]
        best_b, best_F, best_s = bounds[i], F, signs
        for st in step_set:
            for cand in (bounds[i] - st, bounds[i] + st):
                if cand < lo or cand > hi:
                    continue
                trial = bounds.copy(); trial[i] = cand
                s2, F2 = best_signs_for_bounds(C, trial)
                if F2 < best_F - 1e-15:
                    best_b, best_F, best_s = cand, F2, s2
        if best_b != bounds[i]:
            bounds[i] = best_b; F, signs = best_F, best_s; changed = True
    return bounds, signs, F, changed


def _neighborhood_relocate(C, bounds, signs, F, N, deadline):
    d = C.shape[0]
    _, signed = fitness_from_bounds(C, bounds, signs)
    order_meas = np.argsort(-np.abs(signed))          # most imbalanced first
    changed = False
    for j in order_meas[:min(d, 4)]:
        if time.time() > deadline:
            break
        med = _median_of_measure(C, j, N)
        for i in range(1, len(bounds) - 1):
            trial = bounds.copy(); trial[i] = med
            trial = np.sort(trial)
            s2, F2 = best_signs_for_bounds(C, trial)
            if F2 < F - 1e-12:
                bounds, signs, F = trial, s2, F2
                changed = True
                break
        if changed:
            break
    return bounds, signs, F, changed


def local_search(C, bounds, N, max_sweeps=30, step_set=(1, 2, 4),
                 deadline=np.inf):
    bounds = np.sort(bounds.copy())
    signs, F = best_signs_for_bounds(C, bounds)
    for _ in range(max_sweeps):
        if time.time() > deadline:
            break
        bounds, signs, F, c1 = _neighborhood_shift(C, bounds, signs, F,
                                                    step_set, deadline)
        if not c1:
            bounds, signs, F, c2 = _neighborhood_relocate(C, bounds, signs, F,
                                                          N, deadline)
            if not c2:
                break        # VND local optimum w.r.t. both neighborhoods
    return bounds, signs, F


# --------------------------------------------------------------------------
# 1. Brute force (only for tiny instances)
# --------------------------------------------------------------------------
def brute_force(M, N, time_budget=30.0):
    C = prefix(M)
    d = M.shape[0]
    t0 = time.time()
    best_F = np.inf
    best = None
    # enumerate d cut positions among N-1 interior grid points
    for cuts in combinations(range(1, N), d):
        bounds = np.array((0,) + cuts + (N,))
        s, F = best_signs_for_bounds(C, bounds)
        if F < best_F:
            best_F, best = F, (bounds, s)
        if time.time() - t0 > time_budget:
            return best_F, time.time() - t0, False   # incomplete
    return best_F, time.time() - t0, True


# --------------------------------------------------------------------------
# 2. Random multistart + local polish (a strong stochastic baseline)
# --------------------------------------------------------------------------
def random_multistart(M, N, rng, iters=10**9, polish=False,
                      time_budget=np.inf, record=False):
    C = prefix(M)
    d = M.shape[0]
    t0 = time.time()
    best_F = np.inf
    best_bounds = None
    curve = []
    for it in range(iters):
        cuts = np.sort(rng.integers(0, N + 1, size=d))
        bounds = np.concatenate(([0], cuts, [N]))
        bounds = np.maximum.accumulate(bounds)
        bounds[-1] = N
        s, F = best_signs_for_bounds(C, bounds)
        if polish:
            _, _, F = local_search(C, bounds, N, max_sweeps=8)
        if F < best_F:
            best_F, best_bounds = F, bounds
        if it % 32 == 0:
            curve.append((time.time() - t0, best_F))
        if time.time() - t0 > time_budget:
            break
    res = (best_F, time.time() - t0)
    return (res + (curve,)) if record else res


# --------------------------------------------------------------------------
# 3. Particle Swarm on the cross-polytope
# --------------------------------------------------------------------------
def pso(M, N, rng, swarm=40, iters=100000, w=0.72, c1=1.49, c2=1.49,
        time_budget=np.inf, record=False):
    C = prefix(M)
    d = M.shape[0]
    dim = d + 1
    t0 = time.time()
    P = rng.uniform(-1, 1, size=(swarm, dim))
    P /= np.abs(P).sum(axis=1, keepdims=True)
    V = rng.uniform(-0.1, 0.1, size=(swarm, dim))

    def evalpop(P):
        out = np.empty(P.shape[0])
        for k in range(P.shape[0]):
            b, s = polytope_to_bounds(P[k], N)
            out[k], _ = fitness_from_bounds(C, b, s)
        return out

    fit = evalpop(P)
    pbest = P.copy(); pbest_f = fit.copy()
    g = np.argmin(pbest_f); gbest = pbest[g].copy(); gbest_f = pbest_f[g]
    curve = [(time.time() - t0, gbest_f)]
    for _ in range(iters):
        r1 = rng.random((swarm, dim)); r2 = rng.random((swarm, dim))
        V = w * V + c1 * r1 * (pbest - P) + c2 * r2 * (gbest - P)
        P = P + V
        P /= np.abs(P).sum(axis=1, keepdims=True)
        fit = evalpop(P)
        upd = fit < pbest_f
        pbest[upd] = P[upd]; pbest_f[upd] = fit[upd]
        g = np.argmin(pbest_f)
        if pbest_f[g] < gbest_f:
            gbest, gbest_f = pbest[g].copy(), pbest_f[g]
        curve.append((time.time() - t0, gbest_f))
        if time.time() - t0 > time_budget:
            break
    res = (gbest_f, time.time() - t0)
    return (res + (curve,)) if record else res


# --------------------------------------------------------------------------
# 4. Genetic algorithm (mixed length/sign encoding)
# --------------------------------------------------------------------------
def ga(M, N, rng, pop=60, gens=100000, pc=0.9, pm=0.2, elite=3,
       time_budget=np.inf, record=False):
    C = prefix(M)
    d = M.shape[0]
    dim = d + 1
    t0 = time.time()
    # genotype: real vector on cross-polytope (same encoding as PSO)
    G = rng.uniform(-1, 1, size=(pop, dim))
    G /= np.abs(G).sum(axis=1, keepdims=True)

    def evalpop(G):
        out = np.empty(G.shape[0])
        for k in range(G.shape[0]):
            b, s = polytope_to_bounds(G[k], N)
            out[k], _ = fitness_from_bounds(C, b, s)
        return out

    fit = evalpop(G)
    gbest_f = fit.min()
    curve = [(time.time() - t0, gbest_f)]
    for _ in range(gens):
        idx = np.argsort(fit)
        newG = [G[idx[i]].copy() for i in range(elite)]
        while len(newG) < pop:
            # tournament selection
            a = idx[rng.integers(0, pop // 2)]; b = idx[rng.integers(0, pop // 2)]
            p1, p2 = G[a], G[b]
            if rng.random() < pc:                      # arithmetic crossover
                alpha = rng.random()
                child = alpha * p1 + (1 - alpha) * p2
                mask = rng.random(dim) < 0.5            # sign crossover
                child[mask] = np.abs(child[mask]) * np.sign(p1[mask])
                child[~mask] = np.abs(child[~mask]) * np.sign(p2[mask == False])
            else:
                child = p1.copy()
            if rng.random() < pm:                      # mutation
                child += rng.normal(0, 0.05, dim)
                flip = rng.random(dim) < 0.1
                child[flip] *= -1
            s = np.abs(child).sum()
            child = child / s if s > 0 else child
            newG.append(child)
        G = np.array(newG)
        fit = evalpop(G)
        gbest_f = min(gbest_f, fit.min())
        curve.append((time.time() - t0, gbest_f))
        if time.time() - t0 > time_budget:
            break
    res = (gbest_f, time.time() - t0)
    return (res + (curve,)) if record else res


# --------------------------------------------------------------------------
# 5. HCH-MA : Hybrid Consensus-Halving Memetic Algorithm
#    Global PSO exploration + periodic Lamarckian local refinement of elites.
# --------------------------------------------------------------------------
def _greedy_median_bounds(C, d, N):
    med = np.sort([int(np.searchsorted(C[j], 0.5 * C[j, N])) for j in range(d)])
    bounds = np.concatenate(([0], med, [N]))
    bounds = np.maximum.accumulate(bounds).astype(int); bounds[-1] = N
    return bounds


def hchma(M, N, rng, swarm=40, iters=100000, w=0.72, c1=1.49, c2=1.49,
          ls_period=25, ls_elites=3, ls_sweeps=20, seed_greedy=True,
          use_ls=True, adaptive=True, stag_window=8,
          time_budget=np.inf, record=False):
    C = prefix(M)
    d = M.shape[0]
    dim = d + 1
    t0 = time.time()
    P = rng.uniform(-1, 1, size=(swarm, dim))
    P /= np.abs(P).sum(axis=1, keepdims=True)
    V = rng.uniform(-0.1, 0.1, size=(swarm, dim))

    def eval1(p):
        b, s = polytope_to_bounds(p, N)
        f, _ = fitness_from_bounds(C, b, s)
        return f

    def evalpop(P):
        return np.array([eval1(P[k]) for k in range(P.shape[0])])

    def bounds_to_polytope(bounds, signs):
        lengths = (bounds[1:] - bounds[:-1]).astype(float) / N
        lengths = np.maximum(lengths, 1e-9)
        p = lengths * signs
        p /= np.abs(p).sum()
        return p

    fit = evalpop(P)
    pbest = P.copy(); pbest_f = fit.copy()
    # inject the greedy-median construction as one seeded individual
    if seed_greedy:
        gb = _greedy_median_bounds(C, d, N)
        s0, f0 = best_signs_for_bounds(C, gb)
        p0 = bounds_to_polytope(gb, s0)
        worst = np.argmax(pbest_f)
        P[worst] = p0; pbest[worst] = p0; pbest_f[worst] = f0; fit[worst] = f0
    g = np.argmin(pbest_f); gbest = pbest[g].copy(); gbest_f = pbest_f[g]
    curve = [(time.time() - t0, gbest_f)]
    stall = 0
    for it in range(iters):
        r1 = rng.random((swarm, dim)); r2 = rng.random((swarm, dim))
        V = w * V + c1 * r1 * (pbest - P) + c2 * r2 * (gbest - P)
        P = P + V
        P /= np.abs(P).sum(axis=1, keepdims=True)
        fit = evalpop(P)
        upd = fit < pbest_f
        pbest[upd] = P[upd]; pbest_f[upd] = fit[upd]
        # --- decide whether to fire the VND local refinement this iteration ---
        fire = (stall >= stag_window) if adaptive else ((it + 1) % ls_period == 0)
        if use_ls and fire:
                elite_idx = np.argsort(pbest_f)[:ls_elites]
                for ei in elite_idx:
                    b0, s0 = polytope_to_bounds(pbest[ei], N)
                    b1, s1, f1 = local_search(C, b0, N, max_sweeps=ls_sweeps,
                                              deadline=t0 + time_budget)
                    if f1 < pbest_f[ei]:
                        pbest[ei] = bounds_to_polytope(b1, s1)
                        pbest_f[ei] = f1
                        P[ei] = pbest[ei]          # Lamarckian write-back
                stall = 0
        g = np.argmin(pbest_f)
        if pbest_f[g] < gbest_f - 1e-12:
            gbest, gbest_f = pbest[g].copy(), pbest_f[g]; stall = 0
        else:
            stall += 1
        curve.append((time.time() - t0, gbest_f))
        if time.time() - t0 > time_budget:
            break
    # final polish of the global best, honouring the same total time budget
    if use_ls:
        b0, s0 = polytope_to_bounds(gbest, N)
        _, _, f_final = local_search(C, b0, N, max_sweeps=40,
                                     deadline=t0 + time_budget)
        gbest_f = min(gbest_f, f_final)
    curve.append((time.time() - t0, gbest_f))
    res = (gbest_f, time.time() - t0)
    return (res + (curve,)) if record else res


# --------------------------------------------------------------------------
# 6. Differential Evolution (DE/rand/1/bin) on the cross-polytope
# --------------------------------------------------------------------------
def de(M, N, rng, pop=50, F=0.6, CR=0.9, gens=10**9,
       time_budget=np.inf, record=False):
    C = prefix(M)
    d = M.shape[0]
    dim = d + 1
    t0 = time.time()
    X = rng.uniform(-1, 1, size=(pop, dim))
    X /= np.abs(X).sum(axis=1, keepdims=True)

    def ev(x):
        b, s = polytope_to_bounds(x, N)
        f, _ = fitness_from_bounds(C, b, s)
        return f

    f = np.array([ev(X[k]) for k in range(pop)])
    gbest = f.min()
    curve = [(time.time() - t0, gbest)]
    allidx = np.arange(pop)
    for _ in range(gens):
        for i in range(pop):
            r = rng.choice(np.delete(allidx, i), 3, replace=False)
            mutant = X[r[0]] + F * (X[r[1]] - X[r[2]])
            cross = rng.random(dim) < CR
            if not cross.any():
                cross[rng.integers(dim)] = True
            trial = np.where(cross, mutant, X[i])
            s = np.abs(trial).sum()
            trial = trial / s if s > 0 else trial
            ft = ev(trial)
            if ft < f[i]:
                X[i] = trial
                f[i] = ft
        gbest = min(gbest, f.min())
        curve.append((time.time() - t0, gbest))
        if time.time() - t0 > time_budget:
            break
    res = (gbest, time.time() - t0)
    return (res + (curve,)) if record else res


# --------------------------------------------------------------------------
# 7. Grey Wolf Optimizer (GWO) on the cross-polytope
#    The control parameter a decreases from 2 to 0 over the time budget.
# --------------------------------------------------------------------------
def gwo(M, N, rng, pop=40, iters=10**9, time_budget=np.inf, record=False):
    C = prefix(M)
    d = M.shape[0]
    dim = d + 1
    t0 = time.time()
    X = rng.uniform(-1, 1, size=(pop, dim))
    X /= np.abs(X).sum(axis=1, keepdims=True)

    def evalpop(X):
        out = np.empty(X.shape[0])
        for k in range(X.shape[0]):
            b, s = polytope_to_bounds(X[k], N)
            out[k], _ = fitness_from_bounds(C, b, s)
        return out

    f = evalpop(X)
    order = np.argsort(f)
    Xa, Xb, Xd = X[order[0]].copy(), X[order[1]].copy(), X[order[2]].copy()
    fa = f[order[0]]
    curve = [(time.time() - t0, fa)]
    it = 0
    while True:
        frac = min(1.0, (time.time() - t0) / max(time_budget, 1e-9)) \
            if np.isfinite(time_budget) else 1.0 - np.exp(-it / 500.0)
        a = 2.0 - 2.0 * frac
        for i in range(pop):
            A1 = 2 * a * rng.random(dim) - a; C1 = 2 * rng.random(dim)
            X1 = Xa - A1 * np.abs(C1 * Xa - X[i])
            A2 = 2 * a * rng.random(dim) - a; C2 = 2 * rng.random(dim)
            X2 = Xb - A2 * np.abs(C2 * Xb - X[i])
            A3 = 2 * a * rng.random(dim) - a; C3 = 2 * rng.random(dim)
            X3 = Xd - A3 * np.abs(C3 * Xd - X[i])
            xn = (X1 + X2 + X3) / 3.0
            s = np.abs(xn).sum()
            X[i] = xn / s if s > 0 else xn
        f = evalpop(X)
        order = np.argsort(f)
        if f[order[0]] < fa:
            Xa, fa = X[order[0]].copy(), f[order[0]]
        Xb, Xd = X[order[1]].copy(), X[order[2]].copy()
        it += 1
        curve.append((time.time() - t0, fa))
        if time.time() - t0 > time_budget:
            break
    res = (fa, time.time() - t0)
    return (res + (curve,)) if record else res

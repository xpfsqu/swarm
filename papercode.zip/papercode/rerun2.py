"""
Rerun the full experimental suite (exp1-exp4) with the TUNED configuration.
Parallelised across cores. Writes ./results_tuned/*.  Protocol identical to the
original run_experiments.py (same families, sizes, seeds, size-scaled budget),
so results_tuned/ vs code/results/ is a clean before/after comparison.
"""
import os, sys, json, time
import numpy as np
from multiprocessing import Pool
from scipy.stats import wilcoxon

CODE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "original_code")
sys.path.insert(0, CODE)
from chp import make_instance
from solvers import brute_force, random_multistart, pso, ga, de, gwo, hchma

HERE = os.path.dirname(os.path.abspath(__file__))
TUNE = os.path.join(HERE, "tune_out")
OUT = os.path.join(HERE, "results_swevo")
os.makedirs(OUT, exist_ok=True)
NGRID = 5000
EPS_TARGET = 0.05
NPROC = 2

# ---- load tuned configuration ----------------------------------------------
FINAL = json.load(open(os.path.join(TUNE, "final_config.json")))["final"]
W, C1, C2, M_SWARM = FINAL["w"], FINAL["c1"], FINAL["c2"], FINAL["swarm"]
STAG, ETA, SWEEPS = FINAL["stag_window"], FINAL["ls_elites"], FINAL["ls_sweeps"]
try:
    GA_CFG = json.load(open(os.path.join(TUNE, "ga_config.json")))["ga_best"]
except Exception:
    GA_CFG = {"pop": 60, "pc": 0.9, "pm": 0.2}
_dg = json.load(open(os.path.join(TUNE, "de_gwo_config.json")))
DE_CFG, GWO_CFG = _dg["de_best"], _dg["gwo_best"]
print("TUNED HCH-MA/PSO:", FINAL, "| GA:", GA_CFG, "| DE:", DE_CFG, "| GWO:", GWO_CFG, flush=True)

def budget(d):
    return max(0.8, 0.20 * d)

def run_method(name, M, N, seed, T):
    rng = np.random.default_rng(1000 + seed)
    if name == "RAND":
        return random_multistart(M, N, rng, polish=True, time_budget=T)
    if name == "PSO":
        return pso(M, N, rng, swarm=M_SWARM, w=W, c1=C1, c2=C2, time_budget=T)
    if name == "GA":
        return ga(M, N, rng, time_budget=T, **GA_CFG)
    if name == "DE":
        return de(M, N, rng, time_budget=T, **DE_CFG)
    if name == "GWO":
        return gwo(M, N, rng, time_budget=T, **GWO_CFG)
    if name == "HCHMA":
        return hchma(M, N, rng, swarm=M_SWARM, w=W, c1=C1, c2=C2,
                     adaptive=True, stag_window=STAG, ls_elites=ETA,
                     ls_sweeps=SWEEPS, time_budget=T)

METHODS = ["RAND", "PSO", "GA", "DE", "GWO", "HCHMA"]
KINDS = ["uniform", "normal", "adversarial"]

# ---- generic parallel job runner -------------------------------------------
def _job(args):
    tag, name, fam, d, N, iseed, mseed, T = args
    M = make_instance(d, N, fam, np.random.default_rng(iseed))
    f, t = run_method(name, M, N, mseed, T)
    return (tag, name, fam, d, iseed, mseed, float(f), float(t))

def parallel(jobs):
    out = []
    with Pool(NPROC) as pool:
        for r in pool.imap_unordered(_job, jobs):
            out.append(r)
    return out

# ---------------- exp1: main table + Wilcoxon -------------------------------
def exp1(N=NGRID, ds=(2, 4, 8, 16, 24), seeds=range(8)):
    jobs = []
    for kind in KINDS:
        for d in ds:
            T = budget(d)
            for s in seeds:
                for m in METHODS:
                    jobs.append(("e1", m, kind, d, N, 7 * s + 3, s, T))
    res = parallel(jobs)
    # index: (kind,d,s,method)->F
    idx = {}
    for (_, m, fam, d, iseed, s, f, t) in res:
        idx[(fam, d, s, m)] = (f, t)
    rows = []
    baselines = ["RAND", "PSO", "GA", "DE", "GWO"]
    paired = {k: {m: [] for m in METHODS} for k in KINDS}
    for kind in KINDS:
        for d in ds:
            T = budget(d)
            row = {"kind": kind, "d": d, "N": N, "T": T}
            for m in METHODS:
                a = np.array([idx[(kind, d, s, m)][0] for s in seeds])
                tt = np.array([idx[(kind, d, s, m)][1] for s in seeds])
                row[f"{m}_mean"] = float(a.mean()); row[f"{m}_std"] = float(a.std())
                row[f"{m}_time"] = float(tt.mean())
                row[f"{m}_succ"] = float(np.mean(a < EPS_TARGET))
                row[f"{m}_raw"] = [float(x) for x in a]
            for s in seeds:
                for m in METHODS:
                    paired[kind][m].append(idx[(kind, d, s, m)][0])
            rows.append(row)
    sig = {}
    for kind in KINDS:
        h = np.array(paired[kind]["HCHMA"])
        sig[kind] = {"median_HCHMA": float(np.median(h)), "n_pairs": int(len(h))}
        for b in baselines:
            p = np.array(paired[kind][b])
            if np.any(h - p != 0):
                _, pv = wilcoxon(h, p)
            else:
                pv = 1.0
            sig[kind][b] = {"p_value": float(pv), "median": float(np.median(p)),
                            "HCHMA_wins": int(np.sum(h < p)),
                            "baseline_wins": int(np.sum(p < h)),
                            "ties": int(np.sum(h == p))}
    json.dump(rows, open(os.path.join(OUT, "exp1_main.json"), "w"), indent=2)
    json.dump(sig, open(os.path.join(OUT, "exp1_significance.json"), "w"), indent=2)
    print("exp1 done", flush=True)

# ---------------- exp2: scalability -----------------------------------------
def exp2(N=NGRID, ds=(2, 4, 8, 16, 24, 32), kinds=("normal", "adversarial"),
         seeds=range(5)):
    ms = ["PSO", "GA", "DE", "GWO", "HCHMA"]
    jobs = []
    for kind in kinds:
        for d in ds:
            T = budget(d)
            for s in seeds:
                for m in ms:
                    jobs.append(("e2", m, kind, d, N, 11 * s + 5, s, T))
    res = parallel(jobs)
    idx = {}
    for (_, m, fam, d, iseed, s, f, t) in res:
        idx[(fam, d, s, m)] = (f, t)
    rows = []
    for kind in kinds:
        for d in ds:
            T = budget(d)
            row = {"kind": kind, "d": d, "T": T}
            for m in ms:
                a = np.array([idx[(kind, d, s, m)][0] for s in seeds])
                tt = np.array([idx[(kind, d, s, m)][1] for s in seeds])
                row[f"{m}_mean"] = float(a.mean()); row[f"{m}_std"] = float(a.std())
                row[f"{m}_time"] = float(tt.mean())
            rows.append(row)
    json.dump(rows, open(os.path.join(OUT, "exp2_scalability.json"), "w"), indent=2)
    print("exp2 done", flush=True)

# ---------------- exp3: convergence (adversarial d=8, matches text) ----------
def _curve_job(args):
    m, iseed, mseed, T, d, N = args
    M = make_instance(d, N, "adversarial", np.random.default_rng(iseed))
    rng = np.random.default_rng(1000 + mseed)
    if m == "RAND":
        _, _, c = random_multistart(M, N, rng, polish=True, time_budget=T, record=True)
    elif m == "PSO":
        _, _, c = pso(M, N, rng, swarm=M_SWARM, w=W, c1=C1, c2=C2,
                      time_budget=T, record=True)
    elif m == "GA":
        _, _, c = ga(M, N, rng, time_budget=T, record=True, **GA_CFG)
    elif m == "DE":
        _, _, c = de(M, N, rng, time_budget=T, record=True, **DE_CFG)
    elif m == "GWO":
        _, _, c = gwo(M, N, rng, time_budget=T, record=True, **GWO_CFG)
    else:
        _, _, c = hchma(M, N, rng, swarm=M_SWARM, w=W, c1=C1, c2=C2, adaptive=True,
                        stag_window=STAG, ls_elites=ETA, ls_sweeps=SWEEPS,
                        time_budget=T, record=True)
    return m, mseed, c

def exp3(N=NGRID, d=8, seeds=range(6), T=6.0):
    grids = np.linspace(0.05, T, 160)
    jobs = [(m, 13 * s + 2, s, T, d, N) for m in METHODS for s in seeds]
    res = parallel_curves(jobs)
    agg = {}
    for m in METHODS:
        allc = []
        for (mm, s, c) in res:
            if mm != m:
                continue
            ct = np.array([x[0] for x in c]); cf = np.array([x[1] for x in c])
            vals = np.array([cf[ct <= g][-1] if np.any(ct <= g) else cf[0]
                             for g in grids])
            allc.append(vals)
        agg[m] = np.mean(allc, axis=0)
    np.savez(os.path.join(OUT, "exp3_convergence.npz"), grids=grids, **agg)
    print("exp3 done", flush=True)

def parallel_curves(jobs):
    out = []
    with Pool(NPROC) as pool:
        for r in pool.imap_unordered(_curve_job, jobs):
            out.append(r)
    return out

# ---------------- exp4: ablation --------------------------------------------
def _abl_job(args):
    d, name, kw, iseed, mseed, T, N = args
    M = make_instance(d, N, "adversarial", np.random.default_rng(iseed))
    rng = np.random.default_rng(1000 + mseed)
    f, _ = hchma(M, N, rng, swarm=M_SWARM, w=W, c1=C1, c2=C2,
                 time_budget=T, **kw)
    return d, name, float(f)

def exp4(N=NGRID, seeds=range(6), T=4.0):
    variants = {
        "Full (adaptive)": dict(seed_greedy=True,  use_ls=True, adaptive=True,
                                stag_window=STAG, ls_elites=ETA, ls_sweeps=SWEEPS),
        "Periodic VND":    dict(seed_greedy=True,  use_ls=True, adaptive=False,
                                ls_period=15, ls_elites=ETA, ls_sweeps=SWEEPS),
        "No seed":         dict(seed_greedy=False, use_ls=True, adaptive=True,
                                stag_window=STAG, ls_elites=ETA, ls_sweeps=SWEEPS),
        "No VND":          dict(seed_greedy=True,  use_ls=False),
        "Neither (PSO)":   dict(seed_greedy=False, use_ls=False),
    }
    jobs = []
    for d in (8, 16):
        for name, kw in variants.items():
            for s in seeds:
                jobs.append((d, name, kw, 17 * s + 1, s, T, N))
    out = []
    with Pool(NPROC) as pool:
        for r in pool.imap_unordered(_abl_job, jobs):
            out.append(r)
    rows = []
    for d in (8, 16):
        for name in variants:
            vals = [f for (dd, nm, f) in out if dd == d and nm == name]
            rows.append({"d": d, "variant": name,
                         "mean": float(np.mean(vals)), "std": float(np.std(vals))})
    json.dump(rows, open(os.path.join(OUT, "exp4_ablation.json"), "w"), indent=2)
    print("exp4 done", flush=True)

if __name__ == "__main__":
    t0 = time.time()
    exp1(); exp2(); exp3(); exp4()
    print(f"ALL RERUN DONE in {time.time()-t0:.0f}s", flush=True)
    open(os.path.join(OUT, "RERUN_DONE.flag"), "w").write("done")

"""Build the parameter-sensitivity data around the DEPLOYED (rank-selected)
config w=0.4,c1=c2=2.0,m=80,omega=5,eta=1,sweeps=10. For each parameter we vary
it over its range with the others at the deployed value and score configurations
by mean Friedman rank within the slice (the same criterion used for selection),
which is robust to the heterogeneous F-scales of the three families."""
import os, sys, json
import numpy as np
from multiprocessing import Pool
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from tune import CAL, budget, OUT, NGRID, NPROC
CODE = os.path.join(HERE, "original_code")
sys.path.insert(0, CODE)
from chp import make_instance
from solvers import hchma

DEPLOY = {"w": 0.4, "c1": 2.0, "c2": 2.0, "swarm": 80,
          "stag_window": 5, "ls_elites": 1, "ls_sweeps": 10}
GRID = {"w": [0.4, 0.6, 0.72, 0.9], "c1": [1.0, 1.49, 2.0],
        "swarm": [20, 40, 80], "stag_window": [5, 15, 30, 60],
        "ls_elites": [1, 3, 5], "ls_sweeps": [10, 20, 40]}

def key(c):
    return json.dumps({k: c[k] for k in ["w", "c1", "c2", "swarm",
                       "stag_window", "ls_elites", "ls_sweeps"]}, sort_keys=True)

def evalF(c):
    fs = []
    for (fam, d, iseed) in CAL:
        M = make_instance(d, NGRID, fam, np.random.default_rng(iseed))
        rng = np.random.default_rng(50000 + iseed)
        f, _ = hchma(M, NGRID, rng, time_budget=budget(d),
                     seed_greedy=True, use_ls=True, adaptive=True, **c)
        fs.append(float(f))
    return fs

def _w(ck):
    c = json.loads(ck); c["c2"] = c["c1"]
    return ck, evalF(c)

if __name__ == "__main__":
    # memetic slices reuse stage2 (already at w=0.4,phi=2,m=80); PSO-core slices
    # must be computed fresh at the deployed memetic settings.
    need = {}
    for p in ["w", "c1", "swarm"]:
        for v in GRID[p]:
            c = dict(DEPLOY)
            if p == "c1":
                c["c1"] = c["c2"] = v
            else:
                c[p] = v
            need[key(c)] = c
    print(len(need), "PSO-core configs to run", flush=True)
    fresh = {}
    with Pool(NPROC) as pool:
        for ck, fs in pool.imap_unordered(_w, list(need.keys())):
            fresh[ck] = fs
            json.dump(fresh, open(os.path.join(OUT, "sens_core.json"), "w"))
            print("done", ck[:60], round(np.mean(fs), 4), flush=True)
    print("SENS DONE", flush=True)
    open(os.path.join(OUT, "SENS_DONE.flag"), "w").write("done")

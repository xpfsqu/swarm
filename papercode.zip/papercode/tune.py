"""
Parameter tuning for HCH-MA (Computers & Operations Research revision).

Rigorous, reproducible calibration:
  * Calibration instance set is DISJOINT from the test seeds used in
    run_experiments.py (different seed arithmetic + different solver-rng base),
    so tuning never sees a test instance.
  * Objective = mean Friedman-style rank across calibration instances
    (robust to the very different F-scales of the three valuation families).
  * Staged grid search:
       Stage 1  PSO core shared by PSO and HCH-MA:  w, phi(=c1=c2), swarm m
       Stage 2  memetic params given Stage-1 best:  stag_window w_stag,
                                                     ls_elites eta, ls_sweeps
       Stage 3  asymmetric (c1 != c2) probe around the Stage-1 optimum.
  * Tuning budget matches the test budget T(d)=max(0.8,0.20 d).
Outputs ./tune_out/*.json , resumable (skips configs already recorded).
"""
import os, sys, json, time, itertools
import numpy as np
from multiprocessing import Pool

CODE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "original_code")
sys.path.insert(0, CODE)
from chp import make_instance                     # noqa: E402
from solvers import hchma                         # noqa: E402

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tune_out")
os.makedirs(OUT, exist_ok=True)
NGRID = 5000
FAMILIES = ["uniform", "normal", "adversarial"]
CAL_D = [8, 16]
CAL_INST = 3                 # instances per (family, d)  -> 3*3*2 = 18 calib instances
NPROC = 2

def budget(d):
    return max(0.8, 0.20 * d)

# ---- calibration instances (seeds disjoint from the test suite) -------------
def cal_instances():
    """List of (family, d, inst_seed, solver_seed)."""
    fam_off = {"uniform": 0, "normal": 1, "adversarial": 2}
    items = []
    for fam in FAMILIES:
        for d in CAL_D:
            for k in range(CAL_INST):
                inst_seed = 90001 + 101 * k + 7 * d + 1000 * fam_off[fam]
                items.append((fam, d, inst_seed))
    return items

CAL = cal_instances()

def eval_config(cfg):
    """Return list of F over all calibration instances for one HCH-MA config."""
    fs = []
    for (fam, d, inst_seed) in CAL:
        M = make_instance(d, NGRID, fam, np.random.default_rng(inst_seed))
        rng = np.random.default_rng(50000 + inst_seed)
        f, _ = hchma(M, NGRID, rng, time_budget=budget(d),
                     seed_greedy=True, use_ls=True, adaptive=True, **cfg)
        fs.append(float(f))
    return fs

def _worker(args):
    idx, cfg = args
    t0 = time.time()
    fs = eval_config(cfg)
    return idx, fs, time.time() - t0

def run_stage(name, configs):
    """configs: list of (label_dict, hchma_kwargs). Returns records with F lists."""
    fn = os.path.join(OUT, f"{name}.json")
    done = {}
    if os.path.exists(fn):
        for r in json.load(open(fn)):
            done[json.dumps(r["cfg"], sort_keys=True)] = r
    records = [None] * len(configs)
    todo = []
    for i, (label, kw) in enumerate(configs):
        key = json.dumps({**label}, sort_keys=True)
        if key in done:
            records[i] = done[key]
        else:
            todo.append((i, kw, label))
    print(f"[{name}] {len(configs)} configs, {len(todo)} to run", flush=True)
    if todo:
        with Pool(NPROC) as pool:
            for idx, fs, dt in pool.imap_unordered(
                    _worker, [(i, kw) for (i, kw, _) in todo]):
                label = next(l for (j, kw, l) in todo if j == idx)
                rec = {"cfg": label, "F": fs,
                       "mean_overall": float(np.mean(fs))}
                # per-family means
                for fam in FAMILIES:
                    vals = [fs[k] for k, (f, d, s) in enumerate(CAL) if f == fam]
                    rec[f"mean_{fam}"] = float(np.mean(vals))
                records[idx] = rec
                print(f"[{name}] {label} -> overall {np.mean(fs):.4f} "
                      f"adv {rec['mean_adversarial']:.4f} ({dt:.0f}s)", flush=True)
                json.dump([r for r in records if r], open(fn, "w"), indent=2)
    json.dump([r for r in records if r], open(fn, "w"), indent=2)
    return [r for r in records if r]

def rank_select(records):
    """Friedman-style mean rank across calibration instances (lower=better)."""
    M = np.array([r["F"] for r in records])          # (nconf, ninst)
    ranks = np.apply_along_axis(
        lambda col: np.argsort(np.argsort(col)) + 1, 0, M).astype(float)
    mean_rank = ranks.mean(axis=1)
    for r, mr in zip(records, mean_rank):
        r["mean_rank"] = float(mr)
    best = int(np.argmin(mean_rank))
    return best, records

if __name__ == "__main__":
    T_ALL = time.time()
    # ---------------- Stage 1 : PSO core (w, phi, m) -------------------------
    ws   = [0.4, 0.6, 0.72, 0.9]
    phis = [1.0, 1.49, 2.0]
    ms   = [20, 40, 80]
    s1 = []
    for w, phi, m in itertools.product(ws, phis, ms):
        s1.append(({"w": w, "c1": phi, "c2": phi, "swarm": m,
                    "stag_window": 30, "ls_elites": 3, "ls_sweeps": 20},
                   {"w": w, "c1": phi, "c2": phi, "swarm": m,
                    "stag_window": 30, "ls_elites": 3, "ls_sweeps": 20}))
    rec1 = run_stage("stage1_pso", s1)
    b1, rec1 = rank_select(rec1)
    best1 = rec1[b1]["cfg"]
    print("STAGE1 BEST:", best1, "rank", rec1[b1]["mean_rank"], flush=True)

    # ---------------- Stage 2 : memetic (w_stag, eta, sweeps) ----------------
    w0, phi0, m0 = best1["w"], best1["c1"], best1["swarm"]
    stags  = [5, 15, 30, 60]
    etas   = [1, 3, 5]
    sweeps = [10, 20, 40]
    s2 = []
    for sw, eta, sp in itertools.product(stags, etas, sweeps):
        lab = {"w": w0, "c1": phi0, "c2": phi0, "swarm": m0,
               "stag_window": sw, "ls_elites": eta, "ls_sweeps": sp}
        s2.append((lab, dict(lab)))
    rec2 = run_stage("stage2_memetic", s2)
    b2, rec2 = rank_select(rec2)
    best2 = rec2[b2]["cfg"]
    print("STAGE2 BEST:", best2, "rank", rec2[b2]["mean_rank"], flush=True)

    # ---------------- Stage 3 : asymmetric c1,c2 probe -----------------------
    sw0, eta0, sp0 = best2["stag_window"], best2["ls_elites"], best2["ls_sweeps"]
    probes = [(phi0, phi0), (2.05, 0.5), (0.5, 2.05), (1.7, 1.3), (1.3, 1.7)]
    s3 = []
    for c1, c2 in probes:
        lab = {"w": w0, "c1": c1, "c2": c2, "swarm": m0,
               "stag_window": sw0, "ls_elites": eta0, "ls_sweeps": sp0}
        s3.append((lab, dict(lab)))
    rec3 = run_stage("stage3_asym", s3)
    b3, rec3 = rank_select(rec3)
    best3 = rec3[b3]["cfg"]
    print("STAGE3 BEST:", best3, "rank", rec3[b3]["mean_rank"], flush=True)

    final = best3
    json.dump({"final": final,
               "stage1_best": best1, "stage2_best": best2, "stage3_best": best3},
              open(os.path.join(OUT, "final_config.json"), "w"), indent=2)
    print("FINAL CONFIG:", final, flush=True)
    print(f"TOTAL TUNING TIME {time.time()-T_ALL:.0f}s", flush=True)
    open(os.path.join(OUT, "TUNE_DONE.flag"), "w").write("done")
